#include <QApplication>
#include <QWidget>
#include <QtGui>

class MyWidget : public QWidget {
  public:
    MyWidget(QWidget* parent = 0) : QWidget(parent){};

  protected:
    void paintEvent(QPaintEvent*)
    {
        QPainter painter(this);
        QPen pen;
        pen.setWidth(3);
        pen.setBrush(Qt::magenta);
        painter.setPen(pen);
        painter.drawLine(0, 0, 200, 100);
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    MyWidget w;
    w.resize(200, 200);
    w.show();
    return app.exec();
}
