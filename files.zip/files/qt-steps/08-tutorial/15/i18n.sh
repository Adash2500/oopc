qmake QT+=widgets
make
lupdate 15.pro
linguist app_pl.ts
lrelease 15.pro
LC_MESSAGES=pl_PL ./15