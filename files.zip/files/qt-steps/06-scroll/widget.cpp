#include <QApplication>
#include <QScrollArea>
#include <QWidget>
#include <QtGui>

class MyWidget : public QWidget {
    int x, y; // end of line position
  public:
    MyWidget(QWidget* parent = 0) : QWidget(parent), x(200), y(100){};

  protected:
    void paintEvent(QPaintEvent*)
    {
        QPainter painter(this);
        QPen pen;
        pen.setWidth(3);
        pen.setBrush(Qt::magenta);
        painter.setPen(pen);
        painter.drawLine(0, 0, x, y);
    }
    void mousePressEvent(QMouseEvent* event)
    {
        x = event->x();
        y = event->y();
        update();
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QScrollArea a;
    MyWidget* w = new MyWidget;
    w->setMinimumSize(400, 400);
    a.setMinimumSize(200, 200);
    a.setWidget(w);
    a.setWidgetResizable(true);
    a.resize(300, 300);
    a.show();
    return app.exec();
}
