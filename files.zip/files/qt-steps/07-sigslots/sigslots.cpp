#include "sigslots.h"
#include <iostream>
using namespace std;

void Counter::setValue(int value)
{
    if (value != m_value) {
        m_value = value;
        emit valueChanged(value);
    }
}

int main()
{

    Counter a, b;
    QObject::connect(&a, SIGNAL(valueChanged(int)), &b, SLOT(setValue(int)));

    a.setValue(12);
    cout << "a=" << a.value() << ",b=" << b.value() << endl;
    b.setValue(48);
    cout << "a=" << a.value() << ",b=" << b.value() << endl;
}
