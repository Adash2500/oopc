#!/bin/sh
qmake -project
qmake QT+=widgets


