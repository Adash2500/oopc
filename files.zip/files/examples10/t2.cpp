#include <iostream>
using namespace std;

#include "t.h"

void fun(Task* t)
{
    t->get_debug();
}
