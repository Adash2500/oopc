#include <stdlib.h>

int main()
{
    int b;
    int* a = &b;
    *a = 10;
    return 0;
}
