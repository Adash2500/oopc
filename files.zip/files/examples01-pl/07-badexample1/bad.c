#include <stdlib.h>

int main()
{
    int* a;
    *a = 10;
    return 0;
}
