#include "witaj.h"
#include <stdio.h>

int main()
{
    witaj();
    return 0;
}
