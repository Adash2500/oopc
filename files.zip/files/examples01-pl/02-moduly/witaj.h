void witaj(void);
