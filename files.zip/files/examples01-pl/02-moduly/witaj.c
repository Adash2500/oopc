#include "witaj.h"
#include <math.h>
#include <stdio.h>

void witaj(void)
{
    printf("Hello user %g\n", sqrt(16.0));
}
