void push(int a);
int pop(void);
void clear(void);
void init(void);
void finalize(void);
