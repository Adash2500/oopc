gcc -g -Wall -pedantic hello.c -o hello
