gcc -Wall -pedantic --verbose hello.c -o hello
gcc -S hello.c
gcc -c hello.c
